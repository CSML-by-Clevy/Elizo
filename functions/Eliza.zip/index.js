const ElizaNode = require('elizanode');

exports.handler = async function handler(event) {
  if (!event.query) return { error: 'No query parameter' };
  const eliza = new ElizaNode();
  const reply = eliza.transform(event.query);
  if (eliza.quit) {
    return { end: true, message: reply };
  }
  return { end: false, message: reply };

};
